import React from "react"

export default () => <div>Hello world!</div>
